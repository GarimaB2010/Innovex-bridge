# Innovex Bridge — Netlify deployment

This is a static site. Its student, volunteer, speaker/partner, and sponsor forms use Netlify Forms with URL-encoded AJAX submissions. Successful submissions are shown inline and stored in the Netlify site dashboard.

## Deploy

1. Extract `innovex-bridge-netlify.zip`.
2. Deploy the extracted folder containing `index.html` to Netlify.
3. In the Netlify site dashboard, open **Forms** and enable form detection if prompted, then redeploy the site.
4. Submit a real test from the deployed site. Confirm it appears under **Forms**.
5. To receive sponsor inquiries by email, add an email notification in **Forms → Notifications**.

Forms will not submit from a local `file://` preview. They need the deployed Netlify URL and form detection enabled.
