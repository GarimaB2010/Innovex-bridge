(() => {
  const menuButton = document.querySelector('.menu-toggle');
  const navigation = document.querySelector('.main-nav');
  menuButton?.addEventListener('click', () => {
    const isOpen = navigation.classList.toggle('open');
    menuButton.setAttribute('aria-expanded', String(isOpen));
    menuButton.setAttribute('aria-label', isOpen ? 'Close navigation' : 'Open navigation');
  });
  navigation?.querySelectorAll('a').forEach((link) => link.addEventListener('click', () => {
    navigation.classList.remove('open');
    menuButton?.setAttribute('aria-expanded', 'false');
    menuButton?.setAttribute('aria-label', 'Open navigation');
  }));

  const filters = [...document.querySelectorAll('.filter-chip')];
  const cards = [...document.querySelectorAll('.program-card')];
  filters.forEach((filter) => filter.addEventListener('click', () => {
    filters.forEach((item) => item.classList.toggle('active', item === filter));
    const selected = filter.dataset.filter;
    cards.forEach((card) => {
      card.classList.toggle('filtered-out', selected !== 'all' && !card.dataset.category.split(/\s+/).includes(selected));
    });
  }));

  const tabs = [...document.querySelectorAll('.form-tab')];
  const forms = [...document.querySelectorAll('.interest-form')];
  const selectForm = (name) => {
    const selectedTab = tabs.find((tab) => tab.dataset.tab === name);
    if (!selectedTab) return;
    tabs.forEach((item) => {
      const active = item === selectedTab;
      item.classList.toggle('active', active);
      item.setAttribute('aria-selected', String(active));
    });
    forms.forEach((form) => form.classList.toggle('active', form.dataset.form === name));
  };
  tabs.forEach((tab) => tab.addEventListener('click', () => selectForm(tab.dataset.tab)));

  document.querySelectorAll('[data-form-target]').forEach((link) => link.addEventListener('click', () => {
    selectForm(link.dataset.formTarget);
  }));

  forms.forEach((form) => form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (!form.reportValidity()) return;
    const message = form.querySelector('.form-message');
    if (window.location.protocol === 'file:') {
      message.textContent = 'This local preview cannot send forms. Deploy the site to Netlify, enable form detection, then submit from the published site URL.';
      return;
    }
    const submitButton = form.querySelector('[type="submit"]');
    const originalLabel = submitButton.textContent;
    submitButton.disabled = true;
    message.textContent = 'Sending your message…';
    try {
      const formData = new FormData(form);
      formData.set('form-name', form.getAttribute('name'));
      const response = await fetch('/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams(formData).toString()
      });
      if (!response.ok) throw new Error(`Netlify returned HTTP ${response.status}`);
      form.reset();
      message.textContent = 'Thanks for reaching out. Your message was sent to Innovex Bridge.';
    } catch (error) {
      const detail = error instanceof Error ? `${error.message}. ` : '';
      message.textContent = `${detail}Check that form detection is enabled in Netlify and redeploy, then try again from the published site URL.`;
    } finally {
      submitButton.disabled = false;
      submitButton.textContent = originalLabel;
    }
  }));
})();
